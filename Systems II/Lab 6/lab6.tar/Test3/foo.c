
int k = 3;
void foo()
{
    goo();
}
