#include <stdio.h>
void foo();
int main()
{
    foo();
}

void foo()
{
}
