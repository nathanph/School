static int k = 3;

int main()
{
   foo();

}
